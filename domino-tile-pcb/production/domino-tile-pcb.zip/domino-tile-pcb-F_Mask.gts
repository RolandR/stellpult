G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2+dfsg-1*
G04 #@! TF.CreationDate,2026-01-30T02:28:28+01:00*
G04 #@! TF.ProjectId,domino-tile-pcb,646f6d69-6e6f-42d7-9469-6c652d706362,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2+dfsg-1) date 2026-01-30 02:28:28*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X2.250000X0.260000X-2.250000X0.260000X-2.250000X-0.260000X2.250000X-0.260000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X18475000Y-25175000D03*
X10875000Y-25175000D03*
X18475000Y-22635000D03*
X10875000Y-22635000D03*
X18475000Y-20095000D03*
X10875000Y-20095000D03*
X18475000Y-17555000D03*
X10875000Y-17555000D03*
X18475000Y-15015000D03*
X10875000Y-15015000D03*
X18475000Y-12475000D03*
X10875000Y-12475000D03*
G04 #@! TD*
M02*
